export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-gray-900 text-white py-12 sm:py-16 lg:py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-4">Privacy Policy</h1>
          <p className="text-base sm:text-lg text-gray-300">Last updated: {new Date().toLocaleDateString()}</p>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
        <div className="prose prose-sm sm:prose-base lg:prose-lg max-w-none">
          <section className="mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">Introduction</h2>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              BullsEyeEz Marketing ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our services.
            </p>
          </section>

          <section className="mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">Information We Collect</h2>
            <h3 className="text-xl sm:text-2xl font-semibold text-gray-900 mb-3 sm:mb-4">Personal Information</h3>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              We may collect personal information that you voluntarily provide to us when you:
            </p>
            <ul className="list-disc pl-5 sm:pl-6 space-y-2 text-sm sm:text-base text-gray-600 mb-6">
              <li>Fill out contact forms</li>
              <li>Subscribe to our newsletter</li>
              <li>Request a consultation</li>
              <li>Communicate with us via email or phone</li>
            </ul>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              This information may include: name, email address, phone number, company name, and any other information you choose to provide.
            </p>
          </section>

          <section className="mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">How We Use Your Information</h2>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              We use the information we collect to:
            </p>
            <ul className="list-disc pl-5 sm:pl-6 space-y-2 text-sm sm:text-base text-gray-600 mb-6">
              <li>Respond to your inquiries and provide customer support</li>
              <li>Send you marketing communications (with your consent)</li>
              <li>Improve our website and services</li>
              <li>Analyze usage patterns and trends</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section className="mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">Information Sharing</h2>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              We do not sell, trade, or rent your personal information to third parties. We may share your information with:
            </p>
            <ul className="list-disc pl-5 sm:pl-6 space-y-2 text-sm sm:text-base text-gray-600 mb-6">
              <li>Service providers who assist us in operating our website and conducting our business</li>
              <li>Legal authorities when required by law</li>
              <li>Business partners with your explicit consent</li>
            </ul>
          </section>

          <section className="mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">Data Security</h2>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              We implement appropriate technical and organizational security measures to protect your personal information. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.
            </p>
          </section>

          <section className="mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">Your Rights</h2>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              You have the right to:
            </p>
            <ul className="list-disc pl-5 sm:pl-6 space-y-2 text-sm sm:text-base text-gray-600 mb-6">
              <li>Access the personal information we hold about you</li>
              <li>Request correction of inaccurate information</li>
              <li>Request deletion of your personal information</li>
              <li>Opt-out of marketing communications</li>
              <li>Object to processing of your personal information</li>
            </ul>
          </section>

          <section className="mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">Cookies</h2>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              We use cookies and similar tracking technologies to enhance your browsing experience. You can control cookie settings through your browser preferences.
            </p>
          </section>

          <section className="mb-8 sm:mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 sm:mb-6">Contact Us</h2>
            <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4">
              If you have questions about this Privacy Policy, please contact us:
            </p>
            <div className="bg-gray-50 p-4 sm:p-6 rounded-lg space-y-2 text-sm sm:text-base">
              <p className="text-gray-900"><strong>Email:</strong> <a href="mailto:info@bullseyeezmarketing.com" className="text-[#C41102] hover:text-[#9D0D01] break-all">info@bullseyeezmarketing.com</a></p>
              <p className="text-gray-900"><strong>Phone:</strong> <a href="tel:+18003034532" className="text-[#C41102] hover:text-[#9D0D01]">+1 800-303-4532</a></p>
            </div>
          </section>
        </div>

        {/* Back to Home Button */}
        <div className="mt-12 text-center">
          <a
            href="/"
            className="inline-block bg-[#C41102] hover:bg-[#9D0D01] text-white px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl cursor-pointer text-sm sm:text-base min-h-[56px] flex items-center justify-center whitespace-nowrap"
          >
            <i className="ri-arrow-left-line mr-2"></i>
            Back to Home
          </a>
        </div>
      </main>
    </div>
  );
}
