import { useState } from 'react';

const ContactCTA = () => {
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  const handleContactClick = () => {
    try {
      window.location.href = 'mailto:info@bullseyeezmarketing.com';
    } catch (error) {
      console.error('Failed to open email client:', error);
      navigator.clipboard.writeText('info@bullseyeezmarketing.com').then(() => {
        alert('Email copied to clipboard!');
      }).catch(err => {
        console.error('Failed to copy email:', err);
      });
    }
  };

  const handleInquirySubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!email || !firstName || !phone || !message) {
      setSubmitMessage('Please fill in all fields');
      return;
    }

    if (message.length > 500) {
      setSubmitMessage('Message must be 500 characters or less');
      return;
    }

    setIsSubmitting(true);
    setSubmitMessage('');

    try {
      const formData = new URLSearchParams();
      formData.append('firstName', firstName);
      formData.append('email', email);
      formData.append('phone', phone);
      formData.append('message', message);

      const response = await fetch('https://readdy.ai/api/form/d59bqpeisj01hmefr3g0', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData.toString(),
      });

      if (response.ok) {
        setSubmitMessage('Thank you! We\'ll get back to you soon. 🎉');
        setEmail('');
        setFirstName('');
        setPhone('');
        setMessage('');
      } else {
        setSubmitMessage('Something went wrong. Please try again.');
      }
    } catch (error) {
      console.error('Form submission error:', error);
      setSubmitMessage('Failed to submit. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="bg-white py-12 sm:py-16 lg:py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start">
          {/* Left Side - Contact Info & Form */}
          <div className="space-y-6 sm:space-y-8">
            <div className="text-center lg:text-left">
              <h2 className="text-gray-900 text-3xl sm:text-4xl md:text-5xl font-bold mb-4 sm:mb-5">
                Get in Touch
              </h2>
              <p className="text-gray-600 text-base sm:text-lg md:text-xl mb-6 sm:mb-10 max-w-2xl mx-auto lg:mx-0">
                Have a project in mind? We'd love to hear from you. Let's create something amazing together.
              </p>
              <button
                onClick={handleContactClick}
                aria-label="Contact us via email"
                className="bg-[#C41102] text-white border-none py-4 px-8 sm:px-10 text-base sm:text-lg font-semibold cursor-pointer transition-all duration-300 hover:bg-[#9D0D01] hover:-translate-y-0.5 hover:shadow-[0_4px_12px_rgba(196,17,2,0.3)] active:translate-y-0 whitespace-nowrap rounded-lg min-h-[56px] w-full sm:w-auto"
              >
                Contact Us
              </button>
              <div className="mt-6 sm:mt-10 text-gray-600 space-y-2 sm:space-y-3 text-sm sm:text-base">
                <p>
                  Or call us toll free at{' '}
                  <a
                    href="tel:+18003034532"
                    className="text-[#C41102] no-underline transition-colors duration-300 hover:text-[#9D0D01] font-semibold"
                  >
                    +1 800-303-4532
                  </a>
                </p>
                <p className="break-words">
                  Or email us directly at{' '}
                  <a
                    href="mailto:info@bullseyeezmarketing.com"
                    className="text-[#C41102] no-underline transition-colors duration-300 hover:text-[#9D0D01] font-semibold break-all"
                  >
                    info@bullseyeezmarketing.com
                  </a>
                </p>
              </div>
            </div>

            {/* Contact Inquiry Form */}
            <div className="bg-gradient-to-br from-[#C41102] to-[#9D0D01] rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-lg">
              <div className="text-center mb-6">
                <div className="w-14 h-14 sm:w-16 sm:h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                  <i className="ri-message-3-line text-2xl sm:text-3xl text-white"></i>
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-white mb-2">Submit Your Inquiry</h3>
                <p className="text-white/90 text-xs sm:text-sm">
                  Fill out the form below and we'll respond within 24 hours
                </p>
              </div>
              
              <form 
                id="contact-inquiry-form"
                data-readdy-form
                onSubmit={handleInquirySubmit}
                className="space-y-4"
              >
                <div>
                  <input
                    type="text"
                    name="firstName"
                    placeholder="Full Name"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    required
                    className="w-full px-4 py-3 sm:py-4 rounded-lg border-none text-gray-900 text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-white/50 min-h-[48px]"
                  />
                </div>
                
                <div>
                  <input
                    type="email"
                    name="email"
                    placeholder="Email Address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full px-4 py-3 sm:py-4 rounded-lg border-none text-gray-900 text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-white/50 min-h-[48px]"
                  />
                </div>

                <div>
                  <input
                    type="tel"
                    name="phone"
                    placeholder="Phone Number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    required
                    className="w-full px-4 py-3 sm:py-4 rounded-lg border-none text-gray-900 text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-white/50 min-h-[48px]"
                  />
                </div>

                <div>
                  <textarea
                    name="message"
                    placeholder="Tell us about your project or inquiry..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                    maxLength={500}
                    rows={4}
                    className="w-full px-4 py-3 sm:py-4 rounded-lg border-none text-gray-900 text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-white/50 resize-none"
                  />
                  <p className="text-white/70 text-xs mt-1 text-right">
                    {message.length}/500 characters
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-white text-[#C41102] py-3 sm:py-4 px-6 rounded-lg font-semibold cursor-pointer transition-all duration-300 hover:bg-gray-100 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap text-sm sm:text-base min-h-[56px]"
                >
                  {isSubmitting ? 'Sending...' : 'Send Inquiry'}
                </button>

                {submitMessage && (
                  <p className={`text-center text-xs sm:text-sm ${submitMessage.includes('Thank you') ? 'text-white font-semibold' : 'text-white/90'}`}>
                    {submitMessage}
                  </p>
                )}
              </form>
            </div>
          </div>

          {/* Right Side - Booking Calendar */}
          <div className="w-full">
            <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg border border-gray-200">
              <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-4 sm:mb-6 text-center">Schedule a Meeting</h3>
              <div 
                data-oh-booking-calendar-id="BKC-0M6ML27Z5Y" 
                style={{ 
                  minWidth: '280px', 
                  width: '100%',
                  height: '600px',
                  overflow: 'hidden'
                }}
                className="sm:h-[700px]"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactCTA;
