import { useRef } from 'react';

const caseStudies = [
  {
    image: 'https://readdy.ai/api/search-image?query=Real%20completed%20modern%20commercial%20office%20building%20in%20California%20with%20glass%20facade%20and%20steel%20structure%2C%20authentic%20professional%20architectural%20photography%20of%20finished%20construction%20project%20in%20California%20daylight%2C%20documentary%20style%20real%20estate%20photography%20showing%20actual%20built%20environment%20with%20palm%20trees%20and%20clear%20blue%20sky&width=420&height=280&seq=case-california-commercial-006&orientation=landscape',
    category: 'Commercial',
    client: 'Summit Builders',
    title: 'Los Angeles Office Complex Lead Generation',
    roi: '150%',
    timeline: '6 Months',
    location: 'Los Angeles, CA',
    logo: 'https://readdy.ai/api/search-image?query=Professional%20construction%20company%20logo%20design%20with%20simple%20geometric%20shapes%2C%20minimal%20modern%20style%2C%20white%20on%20transparent%20background%2C%20corporate%20identity%20for%20Summit%20Builders&width=160&height=80&seq=logo-summit-001&orientation=landscape'
  },
  {
    image: 'https://readdy.ai/api/search-image?query=Real%20luxury%20custom%20home%20exterior%20completed%20construction%20in%20California%2C%20authentic%20residential%20architecture%20photography%20of%20beautiful%20finished%20house%20with%20modern%20design%20and%20California%20landscaping%2C%20professional%20real%20estate%20photography%20showing%20actual%20built%20California%20home%20with%20natural%20daylight&width=420&height=280&seq=case-california-residential-006&orientation=landscape',
    category: 'Residential',
    client: 'Heritage Homes',
    title: 'San Diego Custom Home Builder Brand Launch',
    roi: '120%',
    timeline: '4 Months',
    location: 'San Diego, CA',
    logo: 'https://readdy.ai/api/search-image?query=Elegant%20home%20builder%20logo%20design%20with%20house%20silhouette%2C%20classic%20typography%2C%20white%20on%20transparent%20background%2C%20professional%20branding%20for%20Heritage%20Homes%20construction%20company&width=160&height=80&seq=logo-heritage-001&orientation=landscape'
  },
  {
    image: 'https://readdy.ai/api/search-image?query=Real%20California%20highway%20bridge%20infrastructure%20construction%20completed%2C%20authentic%20civil%20engineering%20photography%20of%20finished%20transportation%20project%20in%20California%20with%20concrete%20and%20steel%20structure%2C%20documentary%20style%20professional%20photography%20of%20actual%20built%20California%20infrastructure%20in%20natural%20daylight&width=420&height=280&seq=case-california-infrastructure-006&orientation=landscape',
    category: 'Infrastructure',
    client: 'Metro Contractors',
    title: 'Bay Area Municipal Contract Bidding Campaign',
    roi: '180%',
    timeline: '8 Months',
    location: 'San Francisco, CA',
    logo: 'https://readdy.ai/api/search-image?query=Bold%20infrastructure%20contractor%20logo%20with%20engineering%20elements%2C%20industrial%20modern%20design%2C%20white%20on%20transparent%20background%2C%20corporate%20branding%20for%20Metro%20Contractors&width=160&height=80&seq=logo-metro-001&orientation=landscape'
  },
  {
    image: 'https://readdy.ai/api/search-image?query=Real%20industrial%20warehouse%20facility%20completed%20construction%20in%20California%2C%20authentic%20commercial%20building%20photography%20of%20finished%20distribution%20center%20with%20metal%20siding%20and%20loading%20docks%20in%20California%2C%20professional%20architectural%20photography%20of%20actual%20built%20industrial%20structure%20in%20California%20daylight&width=420&height=280&seq=case-california-industrial-006&orientation=landscape',
    category: 'Industrial',
    client: 'Titan Construction',
    title: 'Sacramento Industrial Facility Digital Presence',
    roi: '135%',
    timeline: '5 Months',
    location: 'Sacramento, CA',
    logo: 'https://readdy.ai/api/search-image?query=Strong%20industrial%20construction%20logo%20with%20bold%20typography%20and%20structural%20elements%2C%20modern%20corporate%20design%2C%20white%20on%20transparent%20background%20for%20Titan%20Construction%20company&width=160&height=80&seq=logo-titan-001&orientation=landscape'
  }
];

export default function CaseStudies() {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 444;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="case-studies" className="py-12 sm:py-16 lg:py-24 bg-gray-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 mb-3 sm:mb-4 px-4">
            California Projects &amp; Results
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto px-4">
            See how we're helping <strong>California construction companies</strong> grow their business with targeted <strong>marketing strategies</strong> across the Golden State
          </p>
        </div>

        {/* Horizontal Scroll Gallery - Desktop */}
        <div className="relative hidden lg:block">
          {/* Left Arrow */}
          <button
            onClick={() => scroll('left')}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-[#C41102] hover:bg-[#9D0D01] rounded-full flex items-center justify-center text-white shadow-xl transition-all duration-300 -ml-6 cursor-pointer"
            aria-label="Scroll left"
          >
            <i className="ri-arrow-left-s-line text-2xl"></i>
          </button>

          {/* Scrollable Container */}
          <div
            ref={scrollContainerRef}
            className="flex gap-6 overflow-x-auto scrollbar-hide scroll-smooth pb-4"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {caseStudies.map((study, index) => (
              <div
                key={index}
                className="flex-shrink-0 w-[420px] bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group cursor-pointer border border-gray-200"
              >
                {/* Image Section */}
                <div className="relative h-[280px] overflow-hidden">
                  <img
                    src={study.image}
                    alt={study.title}
                    loading="lazy"
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                  
                  {/* Category Badge */}
                  <div className="absolute top-4 right-4">
                    <span className="px-4 py-2 bg-[#C41102] text-white text-sm font-bold rounded-full whitespace-nowrap">
                      {study.category}
                    </span>
                  </div>

                  {/* Client Logo */}
                  <div className="absolute bottom-4 left-4">
                    <div className="bg-white/95 px-4 py-2 rounded-lg">
                      <span className="text-gray-900 font-bold text-sm whitespace-nowrap">{study.client}</span>
                    </div>
                  </div>
                </div>

                {/* Content Section */}
                <div className="p-8">
                  <div className="flex items-center gap-2 text-[#C41102] mb-3">
                    <i className="ri-map-pin-line text-sm"></i>
                    <span className="text-sm font-semibold whitespace-nowrap">{study.location}</span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-gray-900 mb-6 leading-tight">
                    {study.title}
                  </h3>

                  {/* Metrics */}
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div>
                      <div className="text-3xl font-bold text-[#C41102]">{study.roi}</div>
                      <div className="text-sm text-gray-500 whitespace-nowrap">ROI Increase</div>
                    </div>
                    <div>
                      <div className="text-3xl font-bold text-[#C41102] whitespace-nowrap">{study.timeline}</div>
                      <div className="text-sm text-gray-500 whitespace-nowrap">Timeline</div>
                    </div>
                  </div>

                  {/* View Link */}
                  <div className="flex items-center text-[#C41102] font-semibold group-hover:text-[#9D0D01] transition-colors cursor-pointer">
                    <span className="whitespace-nowrap">View Case Study</span>
                    <i className="ri-arrow-right-line ml-2"></i>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right Arrow */}
          <button
            onClick={() => scroll('right')}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-12 h-12 bg-[#C41102] hover:bg-[#9D0D01] rounded-full flex items-center justify-center text-white shadow-xl transition-all duration-300 -mr-6 cursor-pointer"
            aria-label="Scroll right"
          >
            <i className="ri-arrow-right-s-line text-2xl"></i>
          </button>
        </div>

        {/* Mobile/Tablet Grid View */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 lg:hidden">
          {caseStudies.map((study, index) => (
            <div
              key={index}
              className="bg-white rounded-xl sm:rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group cursor-pointer border border-gray-200"
            >
              {/* Image Section */}
              <div className="relative h-48 sm:h-56 overflow-hidden">
                <img
                  src={study.image}
                  alt={study.title}
                  loading="lazy"
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                
                {/* Category Badge */}
                <div className="absolute top-3 right-3">
                  <span className="px-3 py-1.5 bg-[#C41102] text-white text-xs sm:text-sm font-bold rounded-full whitespace-nowrap">
                    {study.category}
                  </span>
                </div>

                {/* Client Logo */}
                <div className="absolute bottom-3 left-3">
                  <div className="bg-white/95 px-3 py-1.5 rounded-lg">
                    <span className="text-gray-900 font-bold text-xs sm:text-sm whitespace-nowrap">{study.client}</span>
                  </div>
                </div>
              </div>

              {/* Content Section */}
              <div className="p-5 sm:p-6">
                <div className="flex items-center gap-2 text-[#C41102] mb-2">
                  <i className="ri-map-pin-line text-xs sm:text-sm"></i>
                  <span className="text-xs sm:text-sm font-semibold">{study.location}</span>
                </div>
                
                <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-4 leading-tight">
                  {study.title}
                </h3>

                {/* Metrics */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div>
                    <div className="text-2xl sm:text-3xl font-bold text-[#C41102]">{study.roi}</div>
                    <div className="text-xs sm:text-sm text-gray-500">ROI Increase</div>
                  </div>
                  <div>
                    <div className="text-2xl sm:text-3xl font-bold text-[#C41102]">{study.timeline}</div>
                    <div className="text-xs sm:text-sm text-gray-500">Timeline</div>
                  </div>
                </div>

                {/* View Link */}
                <div className="flex items-center text-[#C41102] font-semibold group-hover:text-[#9D0D01] transition-colors cursor-pointer text-sm min-h-[44px]">
                  <span className="whitespace-nowrap">View Case Study</span>
                  <i className="ri-arrow-right-line ml-2"></i>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
