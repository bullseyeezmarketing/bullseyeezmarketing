const Footer = () => {
  return (
    <footer className="bg-gray-100 border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10">
          {/* Company Info */}
          <div className="col-span-1 sm:col-span-2">
            <div className="flex items-center mb-4">
              <img 
                src="https://static.readdy.ai/image/e68229999383205ab39b5de8e92790d3/a7de2b71f71a7da378957435a8d7b4e0.png" 
                alt="Bulls Eye Ez Marketing Logo" 
                loading="lazy"
                className="h-12 sm:h-14 w-auto"
              />
            </div>
            <p className="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 max-w-md">
              Your partner in digital success. We help businesses grow through strategic marketing solutions.
            </p>
            <div className="flex flex-wrap gap-3 sm:gap-4">
              <a 
                href="#" 
                className="w-11 h-11 sm:w-12 sm:h-12 bg-white border border-gray-200 rounded-lg flex items-center justify-center text-gray-600 hover:text-[#C41102] hover:border-[#C41102] transition-colors cursor-pointer"
                aria-label="Facebook"
              >
                <i className="ri-facebook-fill text-lg sm:text-xl"></i>
              </a>
              <a 
                href="#" 
                className="w-11 h-11 sm:w-12 sm:h-12 bg-white border border-gray-200 rounded-lg flex items-center justify-center text-gray-600 hover:text-[#C41102] hover:border-[#C41102] transition-colors cursor-pointer"
                aria-label="Twitter"
              >
                <i className="ri-twitter-fill text-lg sm:text-xl"></i>
              </a>
              <a 
                href="#" 
                className="w-11 h-11 sm:w-12 sm:h-12 bg-white border border-gray-200 rounded-lg flex items-center justify-center text-gray-600 hover:text-[#C41102] hover:border-[#C41102] transition-colors cursor-pointer"
                aria-label="LinkedIn"
              >
                <i className="ri-linkedin-fill text-lg sm:text-xl"></i>
              </a>
              <a 
                href="#" 
                className="w-11 h-11 sm:w-12 sm:h-12 bg-white border border-gray-200 rounded-lg flex items-center justify-center text-gray-600 hover:text-[#C41102] hover:border-[#C41102] transition-colors cursor-pointer"
                aria-label="Instagram"
              >
                <i className="ri-instagram-line text-lg sm:text-xl"></i>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-black font-semibold mb-4 text-base sm:text-lg">Quick Links</h3>
            <ul className="space-y-2 sm:space-y-3">
              <li>
                <a 
                  href="#services" 
                  className="text-sm sm:text-base text-gray-600 hover:text-[#C41102] transition-colors cursor-pointer inline-block min-h-[44px] flex items-center"
                >
                  Services
                </a>
              </li>
              <li>
                <a 
                  href="#case-studies" 
                  className="text-sm sm:text-base text-gray-600 hover:text-[#C41102] transition-colors cursor-pointer inline-block min-h-[44px] flex items-center"
                >
                  Case Studies
                </a>
              </li>
              <li>
                <a 
                  href="#testimonials" 
                  className="text-sm sm:text-base text-gray-600 hover:text-[#C41102] transition-colors cursor-pointer inline-block min-h-[44px] flex items-center"
                >
                  Testimonials
                </a>
              </li>
              <li>
                <a 
                  href="#contact" 
                  className="text-sm sm:text-base text-gray-600 hover:text-[#C41102] transition-colors cursor-pointer inline-block min-h-[44px] flex items-center"
                >
                  Contact
                </a>
              </li>
              <li>
                <a 
                  href="/privacy-policy" 
                  className="text-sm sm:text-base text-gray-600 hover:text-[#C41102] transition-colors cursor-pointer inline-block min-h-[44px] flex items-center"
                >
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-black font-semibold mb-4 text-base sm:text-lg">Contact</h3>
            <ul className="space-y-3 sm:space-y-4">
              <li className="flex items-start gap-2 sm:gap-3">
                <i className="ri-mail-line text-[#C41102] mt-1 text-lg flex-shrink-0"></i>
                <a 
                  href="mailto:info@bullseyeezmarketing.com"
                  className="text-sm sm:text-base text-gray-600 hover:text-[#C41102] transition-colors break-all cursor-pointer"
                >
                  info@bullseyeezmarketing.com
                </a>
              </li>
              <li className="flex items-start gap-2 sm:gap-3">
                <i className="ri-phone-line text-[#C41102] mt-1 text-lg flex-shrink-0"></i>
                <a 
                  href="tel:+18003034532"
                  className="text-sm sm:text-base text-gray-600 hover:text-[#C41102] transition-colors cursor-pointer"
                >
                  +1 800-303-4532
                </a>
              </li>
              <li className="flex items-start gap-2 sm:gap-3">
                <i className="ri-map-pin-line text-[#C41102] mt-1 text-lg flex-shrink-0"></i>
                <span className="text-sm sm:text-base text-gray-600">
                  123 Marketing St, Digital City, DC 12345
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-8 pt-6 sm:pt-8 text-center">
          <p className="text-xs sm:text-sm text-gray-600">
            © {new Date().getFullYear()} BullsEyeEz Marketing. All rights reserved. | <a href="https://readdy.ai/?ref=logo" target="_blank" rel="noopener noreferrer" className="hover:text-[#C41102] transition-colors cursor-pointer">Website Builder</a>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
