import { useState } from 'react';

const Testimonials = () => {
  const [activeTestimonial, setActiveTestimonial] = useState(0);

  const testimonials = [
    {
      id: 1,
      name: 'Sarah Johnson',
      role: 'CEO, TechStart Inc.',
      image: 'https://readdy.ai/api/search-image?query=Professional%20business%20woman%20CEO%20in%20modern%20office%2C%20confident%20smile%2C%20business%20attire%2C%20corporate%20headshot%2C%20clean%20white%20background%2C%20professional%20photography%2C%20high%20quality%20portrait&width=120&height=120&seq=testimonial1&orientation=squarish',
      content: 'BullsEyeEz Marketing transformed our digital presence completely. Their strategic approach and attention to detail resulted in a 300% increase in qualified leads within just 3 months.',
      rating: 5
    },
    {
      id: 2,
      name: 'Michael Chen',
      role: 'Marketing Director, GrowthCo',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Asian%20business%20man%20marketing%20director%2C%20confident%20expression%2C%20business%20suit%2C%20corporate%20headshot%2C%20clean%20white%20background%2C%20professional%20photography%2C%20high%20quality%20portrait&width=120&height=120&seq=testimonial2&orientation=squarish',
      content: 'Working with BullsEyeEz has been a game-changer. Their data-driven strategies and creative campaigns helped us achieve ROI we never thought possible. Highly recommended!',
      rating: 5
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      role: 'Founder, Bloom Boutique',
      image: 'https://readdy.ai/api/search-image?query=Professional%20Hispanic%20business%20woman%20entrepreneur%2C%20warm%20smile%2C%20elegant%20business%20attire%2C%20corporate%20headshot%2C%20clean%20white%20background%2C%20professional%20photography%2C%20high%20quality%20portrait&width=120&height=120&seq=testimonial3&orientation=squarish',
      content: 'The team at BullsEyeEz truly understands what it takes to build a brand. Their comprehensive approach to marketing has helped us grow from a local shop to a regional powerhouse.',
      rating: 5
    },
    {
      id: 4,
      name: 'David Thompson',
      role: 'VP Sales, Enterprise Solutions',
      image: 'https://readdy.ai/api/search-image?query=Professional%20business%20man%20VP%20executive%2C%20confident%20professional%2C%20dark%20business%20suit%2C%20corporate%20headshot%2C%20clean%20white%20background%2C%20professional%20photography%2C%20high%20quality%20portrait&width=120&height=120&seq=testimonial4&orientation=squarish',
      content: 'BullsEyeEz Marketing delivered beyond our expectations. Their strategic insights and execution excellence have made them an invaluable partner in our growth journey.',
      rating: 5
    }
  ];

  const nextTestimonial = () => {
    setActiveTestimonial((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setActiveTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <span className="inline-block px-4 py-2 bg-gray-100 text-gray-700 rounded-full text-xs sm:text-sm font-medium mb-4">
            Client Success Stories
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-3 sm:mb-4 px-4">
            What Our Clients Say
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto px-4">
            Don't just take our word for it. Hear from businesses that have transformed their marketing with BullsEyeEz.
          </p>
        </div>

        {/* Testimonial Carousel */}
        <div className="relative max-w-4xl mx-auto">
          <div className="bg-gray-50 rounded-xl sm:rounded-2xl p-6 sm:p-8 md:p-12 shadow-sm">
            {/* Quote Icon */}
            <div className="flex justify-center mb-4 sm:mb-6">
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-[#C41102] rounded-full flex items-center justify-center">
                <i className="ri-double-quotes-l text-2xl sm:text-3xl text-white"></i>
              </div>
            </div>

            {/* Testimonial Content */}
            <div className="text-center mb-6 sm:mb-8">
              <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-gray-800 leading-relaxed mb-6 sm:mb-8 px-2">
                "{testimonials[activeTestimonial].content}"
              </p>

              {/* Rating Stars */}
              <div className="flex justify-center gap-1 mb-4 sm:mb-6">
                {[...Array(testimonials[activeTestimonial].rating)].map((_, index) => (
                  <i key={index} className="ri-star-fill text-xl sm:text-2xl text-[#C41102]"></i>
                ))}
              </div>

              {/* Client Info */}
              <div className="flex flex-col items-center">
                <img
                  src={testimonials[activeTestimonial].image}
                  alt={testimonials[activeTestimonial].name}
                  loading="lazy"
                  className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover mb-3 sm:mb-4 border-4 border-white shadow-md"
                />
                <h4 className="text-lg sm:text-xl font-bold text-gray-900">
                  {testimonials[activeTestimonial].name}
                </h4>
                <p className="text-sm sm:text-base text-gray-600">
                  {testimonials[activeTestimonial].role}
                </p>
              </div>
            </div>

            {/* Navigation Arrows - Touch Friendly */}
            <div className="flex justify-center items-center gap-3 sm:gap-4">
              <button
                onClick={prevTestimonial}
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center hover:border-[#C41102] hover:bg-[#C41102] hover:text-white transition-all duration-300 group cursor-pointer"
                aria-label="Previous testimonial"
              >
                <i className="ri-arrow-left-s-line text-2xl text-gray-700 group-hover:text-white"></i>
              </button>

              {/* Dots Indicator */}
              <div className="flex gap-2">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setActiveTestimonial(index)}
                    className={`h-3 rounded-full transition-all duration-300 cursor-pointer ${
                      index === activeTestimonial
                        ? 'bg-[#C41102] w-8'
                        : 'bg-gray-300 hover:bg-gray-400 w-3'
                    }`}
                    aria-label={`Go to testimonial ${index + 1}`}
                  />
                ))}
              </div>

              <button
                onClick={nextTestimonial}
                className="w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white border-2 border-gray-200 flex items-center justify-center hover:border-[#C41102] hover:bg-[#C41102] hover:text-white transition-all duration-300 group cursor-pointer"
                aria-label="Next testimonial"
              >
                <i className="ri-arrow-right-s-line text-2xl text-gray-700 group-hover:text-white"></i>
              </button>
            </div>
          </div>
        </div>

        {/* Stats Section - Responsive Grid */}
        <div className="mt-12 sm:mt-16 grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          <div className="text-center">
            <div className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#C41102] mb-2">500+</div>
            <div className="text-sm sm:text-base text-gray-600 font-medium">Happy Clients</div>
          </div>
          <div className="text-center">
            <div className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#C41102] mb-2">98%</div>
            <div className="text-sm sm:text-base text-gray-600 font-medium">Satisfaction Rate</div>
          </div>
          <div className="text-center">
            <div className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#C41102] mb-2">250%</div>
            <div className="text-sm sm:text-base text-gray-600 font-medium">Avg ROI Increase</div>
          </div>
          <div className="text-center">
            <div className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#C41102] mb-2">24/7</div>
            <div className="text-sm sm:text-base text-gray-600 font-medium">Support Available</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
