const services = [
  {
    icon: 'ri-search-line',
    title: 'SEO for Construction',
    description: 'Dominate local search results and get found by California clients actively searching for construction services.',
    features: ['Local SEO optimization', 'Google Business Profile', 'Keyword research', 'Technical SEO audits']
  },
  {
    icon: 'ri-advertisement-line',
    title: 'PPC Advertising',
    description: 'Generate qualified leads fast with targeted Google Ads campaigns designed specifically for construction companies.',
    features: ['Google Ads management', 'Bid optimization', 'Landing page design', 'Conversion tracking']
  },
  {
    icon: 'ri-global-line',
    title: 'Website Design',
    description: 'Professional, mobile-responsive websites that showcase your projects and convert visitors into clients.',
    features: ['Custom design', 'Mobile optimization', 'Project galleries', 'Lead capture forms']
  },
  {
    icon: 'ri-share-line',
    title: 'Social Media Marketing',
    description: 'Build your brand and engage with potential clients on Facebook, Instagram, and LinkedIn.',
    features: ['Content creation', 'Community management', 'Paid social ads', 'Analytics reporting']
  },
  {
    icon: 'ri-mail-line',
    title: 'Email Marketing',
    description: 'Stay top-of-mind with past clients and nurture leads with targeted email campaigns.',
    features: ['Newsletter design', 'Automation setup', 'List segmentation', 'Performance tracking']
  },
  {
    icon: 'ri-line-chart-line',
    title: 'Analytics & Reporting',
    description: 'Track your marketing ROI with detailed reports and data-driven insights for continuous improvement.',
    features: ['Custom dashboards', 'Monthly reports', 'Goal tracking', 'Competitor analysis']
  }
];

export default function Services() {
  return (
    <section id="services" className="py-12 sm:py-16 lg:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-black mb-3 sm:mb-4 px-4">
            Marketing Services Built for Construction
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto px-4">
            Comprehensive digital marketing solutions designed to help <strong>California construction companies</strong> generate more leads and win more projects
          </p>
        </div>

        {/* Services Grid - Responsive */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-12 sm:mb-16">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white border-2 border-gray-200 rounded-xl sm:rounded-2xl p-6 sm:p-8 hover:border-[#C41102] hover:shadow-xl transition-all duration-300 group"
            >
              {/* Icon */}
              <div className="w-14 h-14 sm:w-16 sm:h-16 bg-gray-100 rounded-xl flex items-center justify-center mb-4 sm:mb-6 group-hover:bg-[#C41102] transition-colors duration-300">
                <i className={`${service.icon} text-2xl sm:text-3xl text-[#C41102] group-hover:text-white transition-colors duration-300`}></i>
              </div>

              {/* Title */}
              <h3 className="text-xl sm:text-2xl font-bold text-black mb-3 sm:mb-4">
                {service.title}
              </h3>

              {/* Description */}
              <p className="text-sm sm:text-base text-gray-600 mb-4 sm:mb-6 leading-relaxed">
                {service.description}
              </p>

              {/* Features List */}
              <ul className="space-y-2 sm:space-y-3">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2 sm:gap-3">
                    <i className="ri-check-line text-[#C41102] text-lg sm:text-xl flex-shrink-0 mt-0.5"></i>
                    <span className="text-gray-700 text-xs sm:text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* Learn More Link */}
              <div className="mt-4 sm:mt-6 pt-4 sm:pt-6 border-t border-gray-200">
                <button className="flex items-center text-[#C41102] font-semibold hover:text-[#9D0D01] transition-colors group-hover:gap-2 gap-1 duration-300 cursor-pointer min-h-[44px] text-sm sm:text-base">
                  <span>Learn More</span>
                  <i className="ri-arrow-right-line"></i>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Button */}
        <div className="text-center px-4">
          <a
            href="https://oncehub.com/BullsEyeEzMarketing"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block px-6 sm:px-8 py-4 bg-[#C41102] text-white font-bold rounded-full hover:bg-[#9D0D01] transition-all duration-300 shadow-lg hover:shadow-xl whitespace-nowrap cursor-pointer min-h-[56px] text-sm sm:text-base"
          >
            Schedule Free Consultation
          </a>
        </div>
      </div>
    </section>
  );
}
