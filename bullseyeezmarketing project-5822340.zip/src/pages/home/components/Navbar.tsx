import { useState, useEffect } from 'react';

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu when clicking outside
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isMobileMenuOpen]);

  const navLinks = [
    { href: '#services', label: 'Services' },
    { href: '#case-studies', label: 'Case Studies' },
    { href: '#testimonials', label: 'Testimonials' },
    { href: '#contact', label: 'Contact' },
  ];

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white shadow-lg' : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12">
          <div className="flex items-center justify-between h-16 sm:h-20 lg:h-24">
            {/* Logo */}
            <a href="/" className="flex items-center flex-shrink-0 cursor-pointer">
              <img
                src="https://static.readdy.ai/image/e68229999383205ab39b5de8e92790d3/a7de2b71f71a7da378957435a8d7b4e0.png"
                alt="Bulls Eye Ez Marketing Logo"
                className="h-10 sm:h-12 lg:h-14 w-auto"
                loading="eager"
              />
            </a>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-8">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className={`font-semibold transition-colors duration-300 cursor-pointer text-sm xl:text-base min-h-[44px] flex items-center ${
                    isScrolled
                      ? 'text-gray-900 hover:text-[#C41102]'
                      : 'text-white hover:text-[#C41102]'
                  }`}
                >
                  {link.label}
                </a>
              ))}
              <a
                href="https://oncehub.com/BullsEyeEzMarketing"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#C41102] hover:bg-[#9D0D01] text-white px-6 py-3 rounded-lg font-bold transition-all duration-300 shadow-lg hover:shadow-xl whitespace-nowrap cursor-pointer text-sm xl:text-base min-h-[44px] flex items-center"
              >
                Book Consultation
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className={`lg:hidden w-12 h-12 flex items-center justify-center rounded-lg transition-colors duration-300 ${
                isScrolled ? 'text-gray-900 hover:bg-gray-100' : 'text-white hover:bg-white/10'
              }`}
              aria-label="Toggle mobile menu"
              aria-expanded={isMobileMenuOpen}
            >
              <i className={`${isMobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-2xl`}></i>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Mobile Menu */}
      <div
        className={`fixed top-16 sm:top-20 right-0 bottom-0 w-full sm:w-80 bg-white shadow-2xl z-40 transform transition-transform duration-300 ease-in-out lg:hidden ${
          isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full overflow-y-auto">
          <div className="flex-1 px-6 py-8 space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setIsMobileMenuOpen(false)}
                className="block text-gray-900 hover:text-[#C41102] hover:bg-gray-50 font-semibold py-4 px-4 rounded-lg transition-all duration-300 cursor-pointer min-h-[56px] flex items-center text-base"
              >
                {link.label}
              </a>
            ))}
          </div>
          <div className="p-6 border-t border-gray-200">
            <a
              href="https://oncehub.com/BullsEyeEzMarketing"
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setIsMobileMenuOpen(false)}
              className="block w-full bg-[#C41102] hover:bg-[#9D0D01] text-white text-center px-6 py-4 rounded-lg font-bold transition-all duration-300 shadow-lg cursor-pointer min-h-[56px] flex items-center justify-center"
            >
              Book Consultation
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
