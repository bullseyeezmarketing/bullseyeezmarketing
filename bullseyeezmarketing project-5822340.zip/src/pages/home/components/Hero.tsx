import { useEffect, useRef, useState } from 'react';

export default function Hero() {
  const [imageLoaded, setImageLoaded] = useState(false);
  const imageRef = useRef<HTMLImageElement>(null);

  useEffect(() => {
    if (imageRef.current?.complete) {
      setImageLoaded(true);
    }
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Lazy Loading */}
      <div className="absolute inset-0 bg-gray-900">
        <img
          ref={imageRef}
          src="https://readdy.ai/api/search-image?query=Real%20California%20construction%20site%20with%20modern%20commercial%20building%20under%20construction%2C%20authentic%20professional%20photography%20of%20active%20construction%20project%20in%20California%20with%20blue%20sky%2C%20documentary%20style%20showing%20construction%20workers%20and%20equipment%2C%20natural%20daylight%20photography%20of%20actual%20California%20building%20development&width=1920&height=1080&seq=hero-california-construction-001&orientation=landscape"
          alt="California Construction Marketing"
          loading="eager"
          decoding="async"
          onLoad={() => setImageLoaded(true)}
          className={`w-full h-full object-cover object-top transition-opacity duration-500 ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          }`}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/50 to-black/60"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 xl:px-12 text-center py-12 sm:py-16 lg:py-20">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-white/95 backdrop-blur-sm rounded-full px-4 sm:px-6 py-2 sm:py-3 mb-6 sm:mb-8">
          <i className="ri-map-pin-line text-[#C41102] text-lg sm:text-xl flex-shrink-0"></i>
          <span className="text-gray-900 font-semibold text-sm sm:text-base whitespace-nowrap">
            Serving California Construction Companies
          </span>
        </div>

        {/* Main Heading - Fluid Typography */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-extrabold text-white leading-tight mb-4 sm:mb-6 px-2">
          <span className="text-[#C41102]">BullsEyeEz Marketing</span>
          <br className="hidden sm:block" />
          <span className="sm:hidden"> - </span>
          California's Premier
          <br className="hidden sm:block" />
          <span className="sm:hidden"> </span>
          Construction Marketing Agency
        </h1>

        {/* Subheading - Responsive Text */}
        <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-gray-100 max-w-3xl mx-auto mb-8 sm:mb-12 leading-relaxed px-4">
          We help <strong>California construction companies</strong> and <strong>contractors</strong> generate quality leads, build powerful brands, and dominate their local markets across the Golden State
        </p>

        {/* CTA Buttons - Touch-Friendly */}
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center items-stretch sm:items-center mb-12 sm:mb-16 px-4">
          <a
            href="https://oncehub.com/BullsEyeEzMarketing"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-[#C41102] hover:bg-[#9D0D01] text-white px-6 sm:px-10 py-4 sm:py-5 rounded-xl font-bold text-base sm:text-lg transition-all duration-300 shadow-xl hover:shadow-2xl whitespace-nowrap cursor-pointer text-center min-h-[56px] flex items-center justify-center"
          >
            Get Free Strategy Session
          </a>
          <a
            href="#case-studies"
            className="bg-white hover:bg-gray-100 text-gray-900 px-6 sm:px-10 py-4 sm:py-5 rounded-xl font-bold text-base sm:text-lg transition-all duration-300 shadow-xl whitespace-nowrap cursor-pointer text-center min-h-[56px] flex items-center justify-center"
          >
            View California Projects
          </a>
        </div>

        {/* Stats - Responsive Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 max-w-4xl mx-auto px-4">
          <div className="bg-white/95 backdrop-blur-sm rounded-xl sm:rounded-2xl p-6 sm:p-8">
            <div className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#C41102] mb-2">5+</div>
            <div className="text-gray-900 font-semibold text-sm sm:text-base lg:text-lg">California Clients</div>
          </div>
          <div className="bg-white/95 backdrop-blur-sm rounded-xl sm:rounded-2xl p-6 sm:p-8">
            <div className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#C41102] mb-2">150%</div>
            <div className="text-gray-900 font-semibold text-sm sm:text-base lg:text-lg">Average ROI Growth</div>
          </div>
          <div className="bg-white/95 backdrop-blur-sm rounded-xl sm:rounded-2xl p-6 sm:p-8">
            <div className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#C41102] mb-2">24hrs</div>
            <div className="text-gray-900 font-semibold text-sm sm:text-base lg:text-lg">Response Time</div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator - Hidden on Mobile */}
      <div className="absolute bottom-4 sm:bottom-8 left-1/2 -translate-x-1/2 animate-bounce hidden sm:block">
        <i className="ri-arrow-down-line text-white text-2xl sm:text-3xl"></i>
      </div>
    </section>
  );
}
